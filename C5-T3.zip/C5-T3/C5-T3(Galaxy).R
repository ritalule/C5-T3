library(ggplot2)
library(e1071)
library(caret)
library(corrplot)
library(readr)
library(splines)
library(plyr)
library(dplyr)
library(C50)
library(parallel)
library(foreach)
library(iterators)
library(doParallel)
library(plotly)
library(kknn)

# Find how many cores are on your machine
detectCores() # Result = Typically 4 to 6

# Create Cluster with desired number of cores. Don't use them all! Your computer is running other processes. 
cl <- makeCluster(2)

# Register Cluster
registerDoParallel(cl)

# Confirm how many cores are now "assigned" to R and RStudio
getDoParWorkers() # Result 2 

# Stop Cluster. After performing your tasks, stop your cluster. 
##stopCluster(cl)

## Import Data
galaxy_smallmatrix_labeled_9d <- read.csv("~/Course 5/smallmatrix_labeled_8d/galaxy_smallmatrix_labeled_9d.csv")
View(galaxy_smallmatrix_labeled_9d)

summary(galaxy_smallmatrix_labeled_9d)
str(galaxy_smallmatrix_labeled_9d)

save.image()

# plotting and understanding the data 
galaxyDF<- galaxy_smallmatrix_labeled_9d
summary(galaxyDF)
str(galaxyDF)
plot_ly(galaxyDF, x= ~galaxyDF$galaxysentiment, type='histogram')

# Checking for missing data
sum(is.na(galaxyDF))

# create a new data set and remove features highly correlated with the dependant 
# Identifying collinear variables
galaxyCOR<- cor(galaxyDF)
corrplot(galaxyCOR)
ncol(galaxyDF)

galaxy <- findCorrelation(galaxyCOR, cutoff = 0.9, verbose = FALSE, names = FALSE, exact = ncol(galaxyCOR))
options(max.print=1000000)
galaxy

# Removing Collinear variables
galaxyCOR[c(29,24,56,34,21,31,51,46,16,57,55,30,6,5)] <- NULL
str(galaxyCOR)
summary(galaxyCOR)

# Testing Collinearity:
ncol(galaxyDF)
galaxyCOR <- cor(galaxyDF)
findCorrelation(galaxyCOR, cutoff = 0.9, verbose = FALSE, names = FALSE, exact = ncol(galaxyCOR))
ncol(galaxyCOR)

#NearZeroVar Test and Removal of Zero Var Predictors
#df_1
nzvMetrics1 <- nearZeroVar(galaxyDF, saveMetrics = TRUE)
nzvMetrics1

# nearZeroVar() with saveMetrics = FALSE returns an vector 
nzv1 <- nearZeroVar(galaxyDF, saveMetrics = FALSE) 
nzv1


# create a new data set and remove near zero variance features
galaxyNZV <- galaxyDF[,-nzv1]
str(galaxyNZV)

# Let's sample the data before using RFE
set.seed(123)
galaxySample <- galaxyDF[sample(1:nrow(galaxyDF), 1000, replace=FALSE),]

## Change Brand to a factor
galaxyDF$galaxysentiment <- as.factor(galaxyDF$galaxysentiment)


# Set up rfeControl with randomforest, repeated cross validation and no updates
ctrl <- rfeControl(functions = rfFuncs, 
                   method = "repeatedcv",
                   repeats = 5,
                   verbose = FALSE)

# Use rfe and omit the response variable (attribute 59 iphonesentiment) 
rfeResults <- rfe(galaxySample[,1:58], 
                  galaxySample$galaxysentiment, 
                  sizes=(1:58), 
                  rfeControl=ctrl)

# Get results
rfeResults

# Plot results
plot(rfeResults, type=c("g", "o"))

# create new data set with rfe recommended features
galaxyRFE <- galaxyDF[,predictors(rfeResults)]

# add the dependent variable to galaxyRFE
galaxyRFE$galaxysentiment <- galaxyDF$galaxysentiment

# review outcome
str(galaxyRFE)

save.image()

dataPargal <- createDataPartition(galaxyDF$galaxysentiment, p = .70, list = FALSE)
training <- galaxyDF[dataPargal,]
testing <- galaxyDF[-dataPargal,]
str(galaxyDF)
summary(galaxyDF)
is.na(galaxyDF)



# cross validation 
fitControl <- trainControl(method = "repeatedcv", number = 10, repeats = 1)

##### Decision Tree (C5.0) #####
c5_galaxyDF <- train(galaxysentiment~., data=training, method="C5.0", trControl = fitControl, tuneLength = 3)
c5_galaxyDF
gc50 <- predict(c5_galaxyDF, testing) 
postResample(gc50, testing$galaxysentiment)

gbm_galaxyDF <- train(galaxysentiment~., data = training, 
                      method = "gbm", 
                      trControl = fitControl,
                      ## This last option is actually one
                      ## for gbm() that passes through
                      verbose = FALSE)
gbm_iphoneDF
pgbm <- predict(gbm_iphoneDF, testing) 
postResample(pgbm, testing$galaxysentiment)


##### Random Forest  #####
RF_galaxyDF <- train(galaxysentiment~., data = training, method = "rf", trControl=fitControl)
RF_galaxyDF
grf <- predict(RF_galaxyDF, testing) 
postResample(prf, testing$galaxysentiment)


##### knn  #####
knn_galaxyDF <- train(galaxysentiment~., data=training, method="kknn",trControl=fitControl)
gknn <- predict(knn_galaxyDF, testing) 
postResample(gknn, testing$galaxysentiment)
knn_galaxyDF


##### Support Vector Machine #####
# SVM (from the e1071 package) 
svm_galaxyDF <- svm(galaxysentiment~., data=training, method = "svmLinear2", trControl = fitControl)
svm_galaxyDF
gsvm <- predict(svm_galaxyDF, testing) 
postResample(gsvm, testing$galaxysentiment)
--------------------------------------------------------------------------------------

# Create a confusion matrix from random forest predictions 
gcmsvm <- confusionMatrix(gsvm, testing$galaxysentiment) 
gcmsvm

gcmknn <- confusionMatrix(gknn, testing$galaxysentiment) 
gcmknn

gcmprf <- confusionMatrix(grf, testing$galaxysentiment) 
gcmprf

gcmpc50 <- confusionMatrix(gc50, testing$galaxysentiment) 
gcmpc50

gcmpgbm <- confusionMatrix(pgbm, testing$galaxysentiment) 
gcmpgbm

save.image()

# create a new dataset that will be used for recoding sentiment
galaxyRC <- galaxyDF
# recode sentiment to combine factor levels 0 & 1 and 4 & 5
galaxyRC$galaxysentiment <-as.factor(galaxyRC$galaxysentiment)
galaxyRC$galaxysentiment <- recode(galaxyRC$galaxysentiment, '0' = 1, '1' = 1, '2' = 2, '3' = 3, '4' = 4, '5' = 4) 
# inspect results
summary(galaxyRC)
sum(is.na(galaxyRC))
iphoneRC <- na.omit(galaxyRC) 
str(galaxyRC)
str(galaxyRC$galaxysentiment)

# data = training and testing from iphoneDF (no feature selection) 
# create object containing centered, scaled PCA components from training set
# excluded the dependent variable and set threshold to .95
preprocessParams <- preProcess(training[,-59], method=c("center", "scale", "pca"), thresh = 0.95)
print(preprocessParams)

# use predict to apply pca parameters, create training, exclude dependant
train.pca <- predict(preprocessParams, training[,-59])

# add the dependent to training
train.pca$igalaxysentiment <- training$igalaxysentiment

# use predict to apply pca parameters, create testing, exclude dependant
test.pca <- predict(preprocessParams, testing[,-59])

# add the dependent to training
test.pca$galaxysentiment <- testing$galaxysentiment

# inspect results
str(train.pca)
str(test.pca)



# create training and testing sets
inT_galaxyRC <- createDataPartition(galaxyRC$galaxysentiment, p = .70, list = FALSE)
galaxyRC_train <- galaxyRC[inT_galaxyRC, ]
galaxyRC_test <- galaxyRC[-inT_galaxyRC, ]
## apply c5.0 algorithm
galaxyRF.0_RC <- train(galaxysentiment~., data = galaxyRC_train, method = "rf", trControl=fitControl)

# make predictions 
galaxyRF_RCpred <- predict(galaxyRF.0_RC, galaxyRC_test)


#evaluate
postResample(galaxyRF_RCpred, galaxyRC_test$galaxysentiment)

save.image()

galaxyLargeMatrix <- read.csv("C:/Users/Ameha/Desktop/Output1/LargeMatrix.csv")
View(galaxyLargeMatrix)
str(galaxyLargeMatrix)
summary(galaxyLargeMatrix)
galaxyLargeMatrix$id <- NULL


# make the prediction for iphone 
galaxyLargeMatrix_pred <- predict(galaxyRF.0_RC, galaxyLargeMatrix)
summary(galaxyLargeMatrix_pred)


#evaluate
postResample(galaxyLargeMatrix_pred, galaxyRC_test$galaxysentiment)

save.image()


