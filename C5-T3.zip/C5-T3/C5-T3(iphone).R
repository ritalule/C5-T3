library(ggplot2)
library(e1071)
library(caret)
library(corrplot)
library(readr)
library(splines)
library(gbm)
library(plyr)
library(dplyr)
library(C50)
library(parallel)
library(foreach)
library(iterators)
library(doParallel)
library(plotly)
library(kknn)
library(randomForest)

# Find how many cores are on your machine
detectCores() # Result = Typically 4 to 6

# Create Cluster with desired number of cores. Don't use them all! Your computer is running other processes. 
cl <- makeCluster(2)

# Register Cluster
registerDoParallel(cl)

# Confirm how many cores are now "assigned" to R and RStudio
getDoParWorkers() # Result 2 

# Stop Cluster. After performing your tasks, stop your cluster. 
#stopCluster(cl)

## Import Data
iphone_smallmatrix_labeled_8d <- read.csv("~/Course 5/smallmatrix_labeled_8d/iphone_smallmatrix_labeled_8d.csv")
View(iphone_smallmatrix_labeled_8d)

save.image()

summary(iphone_smallmatrix_labeled_8d)
str(iphone_smallmatrix_labeled_8d)

# plotting and understanding the data 
iphoneDF<- iphone_smallmatrix_labeled_8d
summary(iphoneDF)
str(iphoneDF)
plot_ly(iphoneDF, x= ~iphoneDF$iphonesentiment, type='histogram')

# Checking for missing data
sum(is.na(iphoneDF))

# create a new data set and remove features highly correlated with the dependant 
# Identifying collinear variables
iphoneCOR<- cor(iphoneDF)
corrplot(iphoneCOR)
ncol(iphoneDF)

s <- findCorrelation(iphoneCOR, cutoff = 0.9, verbose = FALSE, names = FALSE, exact = ncol(iphoneCOR))
options(max.print=1000000)
s

# Removing Collinear variables
iphoneCOR[c(29,24,56,34,21,31,51,46,16,57,55,6,5)] <- NULL
str(iphoneCOR)
summary(iphoneCOR)

# Testing Collinearity:
ncol(iphoneDF)
iphoneCOR <- cor(iphoneDF)
findCorrelation(iphoneCOR, cutoff = 0.9, verbose = FALSE, names = FALSE, exact = ncol(iphoneCOR))
ncol(iphoneCOR)

#NearZeroVar Test and Removal of Zero Var Predictors
#df_1
nzvMetrics <- nearZeroVar(iphoneDF, saveMetrics = TRUE)
nzvMetrics

# nearZeroVar() with saveMetrics = FALSE returns an vector 
nzv <- nearZeroVar(iphoneDF, saveMetrics = FALSE) 
nzv


# create a new data set and remove near zero variance features
iphoneNZV <- iphoneDF[,-nzv]
str(iphoneNZV)

# Let's sample the data before using RFE
set.seed(123)
iphoneSample <- iphoneDF[sample(1:nrow(iphoneDF), 1000, replace=FALSE),]

## Change Brand to a factor
iphoneDF$iphonesentiment <- as.factor(iphoneDF$iphonesentiment)


# Set up rfeControl with randomforest, repeated cross validation and no updates
ctrl <- rfeControl(functions = rfFuncs, 
                   method = "repeatedcv",
                   repeats = 5,
                   verbose = FALSE)

# Use rfe and omit the response variable (attribute 59 iphonesentiment) 
rfeResults <- rfe(iphoneSample[,1:58], 
                  iphoneSample$iphonesentiment, 
                  sizes=(1:58), 
                  rfeControl=ctrl)

# Get results
rfeResults

# Plot results
plot(rfeResults, type=c("g", "o"))

# create new data set with rfe recommended features
iphoneRFE <- iphoneDF[,predictors(rfeResults)]

# add the dependent variable to iphoneRFE
iphoneRFE$iphonesentiment <- iphoneDF$iphonesentiment

# review outcome
str(iphoneRFE)

save.image()

dataPar <- createDataPartition(iphoneDF$iphonesentiment, p = .70, list = FALSE)
training <- iphoneDF[dataPar,]
testing <- iphoneDF[-dataPar,]
str(iphoneDF)
summary(iphoneDF)
is.na(iphoneDF)



# cross validation 
fitControl <- trainControl(method = "repeatedcv", number = 10, repeats = 1)

##### Decision Tree (C5.0) #####
c5_iphoneDF <- train(iphonesentiment~., data=training, method="C5.0", trControl = fitControl, tuneLength = 3)
c5_iphoneDF
pc50 <- predict(c5_iphoneDF, testing) 
postResample(pc50, testing$iphonesentiment)

##### Stochastic Gradient Boosting   #####

gbm_iphoneDF <- train(iphonesentiment~., data = training, 
                 method = "gbm", 
                 trControl = fitControl,
                   verbose = FALSE)
gbm_iphoneDF
pgbm <- predict(gbm_iphoneDF, testing) 
postResample(pgbm, testing$iphonesentiment)


##### Random Forest  #####
RF_iphoneDF <- train(iphonesentiment~., data = training, method = "rf", trControl=fitControl)
RF_iphoneDF
prf <- predict(RF_iphoneDF, testing) 
postResample(prf, testing$iphonesentiment)


##### knn  #####
knn_iphoneDF <- train(iphonesentiment~., data=training, method="kknn",trControl=fitControl)
pknn <- predict(knn_iphoneDF, testing) 
postResample(pknn, testing$iphonesentiment)
knn_iphoneDF


##### Support Vector Machine #####
# SVM (from the e1071 package) 
svm_iphoneDF <- svm(iphonesentiment~., data=training, method = "svmLinear2", trControl = fitControl)
svm_iphoneDF
psvm <- predict(svm_iphoneDF, testing) 
postResample(psvm, testing$iphonesentiment)

# Create a confusion matrix from random forest predictions 
cmsvm <- confusionMatrix(psvm, testing$iphonesentiment) 
cmsvm

cmknn <- confusionMatrix(pknn, testing$iphonesentiment) 
cmknn

cmprf <- confusionMatrix(prf, testing$iphonesentiment) 
cmprf

cmpc50 <- confusionMatrix(pc50, testing$iphonesentiment) 
cmpc50

cmpgbm <- confusionMatrix(pgbm, testing$iphonesentiment) 
cmpgbm

save.image()

# create a new dataset that will be used for recoding sentiment
iphoneRC <- iphoneDF
# recode sentiment to combine factor levels 0 & 1 and 4 & 5
iphoneRC$iphonesentiment <-as.factor(iphoneRC$iphonesentiment)
iphoneRC$iphonesentiment <- recode(iphoneRC$iphonesentiment, '0' = 1, '1' = 1, '2' = 2, '3' = 3, '4' = 4, '5' = 4) 
# inspect results
summary(iphoneRC)
sum(is.na(iphoneRC))
iphoneRC <- na.omit(iphoneRC) 
str(iphoneRC)
str(iphoneRC$iphonesentiment)

# data = training and testing from iphoneDF (no feature selection) 
# create object containing centered, scaled PCA components from training set
# excluded the dependent variable and set threshold to .95
preprocessParams <- preProcess(training[,-59], method=c("center", "scale", "pca"), thresh = 0.95)
print(preprocessParams)

# use predict to apply pca parameters, create training, exclude dependant
train.pca <- predict(preprocessParams, training[,-59])

# add the dependent to training
train.pca$iphonesentiment <- training$iphonesentiment

# use predict to apply pca parameters, create testing, exclude dependant
test.pca <- predict(preprocessParams, testing[,-59])

# add the dependent to training
test.pca$iphonesentiment <- testing$iphonesentiment

# inspect results
str(train.pca)
str(test.pca)

# create training and testing sets
inT_iphoneRC <- createDataPartition(iphoneRC$iphonesentiment, p = .70, list = FALSE)
iphoneRC_train <- iphoneRC[inT_iphoneRC, ]
iphoneRC_test <- iphoneRC[-inT_iphoneRC, ]
## apply c5.0 algorithm
iphoneRF_RC <- train(iphonesentiment~., data = iphoneRC_train, method = "rf", trControl=fitControl)

# make predictions 
iphoneRF_RCpred <- predict(iphoneRF_RC, iphoneRC_test)

#evaluate
postResample(iphoneRF_RCpred, iphoneRC_test$iphonesentiment)
cm_iphoneRF_RC <- confusionMatrix(iphoneRF_RCpred, iphoneRC_test$iphonesentiment)


save.image()

iphoneLargeMatrix <- read.csv("C:/Users/Ameha/Desktop/Output1/iphoneLargeMatrix.csv")
View(iphoneLargeMatrix)
str(iphoneLargeMatrix)
summary(iphoneLargeMatrix)
iphoneLargeMatrix$id <- NULL


# make the prediction for iphone 
iphoneLargeMatrix_pred <- predict(iphoneRF_RC, iphoneLargeMatrix)
summary(iphoneLargeMatrix_pred)

#evaluate
postResample(iphoneLargeMatrix_pred, galaxyRC_test$galaxysentiment)